/* jshint devel:true */
requirejs.config({
    baseUrl: '/js',
    paths: {
        // app: '/app/scripts/'
    }
}); 
requirejs(['user']);
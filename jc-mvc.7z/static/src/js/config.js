/**
 *  Model Config
 */
define(['config'], function(Config) {
    'use strict';
    return {
        apiurl: 'http://mvc.jc.me:81/'
    }

});


